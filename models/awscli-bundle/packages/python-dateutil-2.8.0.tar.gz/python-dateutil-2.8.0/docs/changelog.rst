.. Changelog transcluded from the NEWS file

=========
Changelog
=========

.. include:: ../NEWS
