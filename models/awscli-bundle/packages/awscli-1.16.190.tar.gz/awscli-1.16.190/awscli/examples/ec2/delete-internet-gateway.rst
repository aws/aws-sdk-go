**To delete an Internet gateway**

This example deletes the specified Internet gateway. If the command succeeds, no output is returned.

Command::

  aws ec2 delete-internet-gateway --internet-gateway-id igw-c0a643a9
